//action type constants
export const TOGGLE_MESSAGE = 'TOGGLE_MESSAGE'


//actioncreators
export function toggleMessage(){
    return {
        type : 'TOGGLE_MESSAGE'
    }
}


  



